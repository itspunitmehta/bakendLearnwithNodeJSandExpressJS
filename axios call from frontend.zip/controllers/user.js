const req = require('express/lib/request');
const User = require('../models/users');
// const bodyParser = require('body-parser');



exports.getAddUser = (req,res,next) => {
    res.render('admin/creat-user', {
      pageTitle: 'Add User',
      path: '/admin/users',
    });
  }
  
  exports.postAddUser = (req,res,next) => {
    const name = req.body.name;
    const email = req.body.email;
    const phone = req.body.phone;
    const address = req.body.address;
    User.create({
      name: name,
      phone: phone,
      email: email,
      address: address
    })
    .then(result => {
      console.log('User Created');
    })
    .catch(err => {
      console.log(err)
    })
  }
  
  exports.getUsers = (req,res,next) => {
    // console.log(req.query.id);
    const id = req.query.id*1;// req.query.id was a string so to convert that to int we did this
    User.findAll()
    .then(users=>{
        if(id){
        users.forEach(user=>{
            if(id===user.id){
            res.json(user);
            }
        })
        }
      res.json(users)
    })
    .catch(err=>{
      console.log(err)
    })
  }

  exports.postDeleteUser = (req,res,next) => {
      const id = req.body.id;
    console.log(req.body.name)
      User.findByPk(id)
      .then(user => {
          return user.destroy();
      })
      .then(result =>{
          console.log("User Deleted")
      })
      .catch(err => {
          console.log(err);
      })
  }