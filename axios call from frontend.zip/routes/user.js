const path = require('path');

const express = require('express');

const userController = require('../controllers/user');

const router = express.Router();

router.get('/users', userController.getAddUser);

router.post('/userdetails', userController.postAddUser);

router.get('/userdetails', userController.getUsers);

router.post('/userdelete', userController.postDeleteUser);

module.exports = router;
