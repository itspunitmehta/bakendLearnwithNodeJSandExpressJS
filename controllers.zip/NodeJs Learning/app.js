const path = require('path');

const express = require('express');
const bodyParser = require('body-parser');

const app = express();

const errorController = require('./controllers/error');

const adminRoutes = require('./routers/admin');
const shopRoutes = require('./routers/shop');

app.use(bodyParser.urlencoded({extended:false}));
app.use(express.static(path.join(__dirname, 'public')))

app.use('/admin',adminRoutes);
app.use('/shop',shopRoutes);

app.use(errorController.getError404);

app.listen(3000);