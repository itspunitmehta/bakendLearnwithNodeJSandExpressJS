const path = require('path');

const express = require('express');

const rootDir = require('../util/path');

const router = express.Router();

const contactController = require('../controllers/contactus');
const productController = require('../controllers/product');

router.get('/add-product', productController.getAddProduct);
  
  router.post('/add-product', productController.postAddProduct);

router.get('/contact', contactController.getContactUs);


router.post('/contact',contactController.postContactUs);

  module.exports = router;